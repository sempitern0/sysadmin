@echo off
:: ============================================================================
:: Script de Instalación de Office 365 - Office Deployment Tool (ODT)
:: ============================================================================

title Instalador de Microsoft Office 365 (ODT)

:: 1. Cambiar la ruta de trabajo al directorio donde se encuentra este archivo .bat
cd /d "%~dp0"

echo ============================================================================
echo               INSTALADOR DE MICROSOFT OFFICE 365 (ODT)
echo ============================================================================
echo.

:: 2. Comprobar permisos de Administrador
net session >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Este script requiere permisos de ADMINISTRADOR.
    echo Por favor, haz clic derecho sobre este archivo y selecciona "Ejecutar como administrador".
    echo.
    pause
    exit /b 1
)

:: 3. Verificar la existencia de los archivos requeridos
if not exist "setup.exe" (
    echo [ERROR] No se encontro 'setup.exe' en la carpeta actual:
    echo %cd%
    echo Asegurate de que 'setup.exe' este guardado en la misma carpeta que este script.
    echo.
    pause
    exit /b 1
)

if not exist "configuration-Office365-x64.xml" (
    echo [ERROR] No se encontro 'configuration-Office365-x64.xml' en la carpeta actual:
    echo %cd%
    echo Asegurate de que el archivo XML este guardado en la misma carpeta.
    echo.
    pause
    exit /b 1
)

echo [INFO] Archivos verificados correctamente.
echo [INFO] Iniciando la instalacion de Microsoft Office 365...
echo Por favor, espera a que finalice el proceso...
echo.

:: 4. Ejecutar la instalacion
setup.exe /configure configuration-Office365-x64.xml

:: 5. Comprobar el codigo de salida
if %errorlevel% equ 0 (
    echo.
    echo ============================================================================
    echo [EXITO] La instalacion ha finalizado correctamente.
    echo ============================================================================
) else (
    echo.
    echo ============================================================================
    echo [ERROR] La instalacion ha finalizado con el codigo de error: %errorlevel%
    echo ============================================================================
)

echo.
pause