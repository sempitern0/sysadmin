@echo off
REM Cambiar al directorio de Office 16
cd /d "%ProgramFiles%\Microsoft Office\Office16"

REM Buscar y registrar la licencia
for /f %%x in ('dir /b ..\root\Licenses16\ProPlus2021VL_KMS*.xrm-ms') do (
    cscript ospp.vbs /inslic:"..\root\Licenses16\%%x"
)

REM Configurar el puerto KMS
cscript ospp.vbs /setprt:1688

REM Desinstalar clave de producto previa (si existe)
cscript ospp.vbs /unpkey:GCVGB >nul

REM Instalar la nueva clave de producto
cscript ospp.vbs /inpkey:XJ2XN-FW8RK-P4HMP-DKDBV-GCVGB

REM Configurar el servidor KMS
cscript ospp.vbs /sethst:e8.us.to

REM Activar Office
cscript ospp.vbs /act

pause