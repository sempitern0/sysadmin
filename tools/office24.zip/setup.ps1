# ============================================================================
# Script de Instalación de Office 365 - Office Deployment Tool (ODT)
# ============================================================================

# Título del script
Write-Host "===============================" -ForegroundColor Cyan
Write-Host "INSTALADOR DE MICROSOFT OFFICE 365 (ODT)" -ForegroundColor Cyan
Write-Host "===============================" -ForegroundColor Cyan
Write-Host

# 1. Cambiar la ruta de trabajo al directorio donde se encuentra este archivo
Set-Location -Path $PSScriptRoot

# 2. Comprobar permisos de Administrador
$currentUser = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $currentUser.IsInRole([Security.Principal.WindowsBuiltinRole]::Administrator)) {
    Write-Host "[ERROR] Este script requiere permisos de ADMINISTRADOR." -ForegroundColor Red
    Write-Host "Por favor, haz clic derecho sobre este archivo y selecciona 'Ejecutar como administrador'." -ForegroundColor Yellow
    Pause
    exit
}

# 3. Verificar la existencia de los archivos requeridos
if (-not (Test-Path -Path "setup.exe")) {
    Write-Host "[ERROR] No se encontró 'setup.exe' en la carpeta actual:" -ForegroundColor Red
    Write-Host (Get-Location) -ForegroundColor Yellow
    Write-Host "Asegúrate de que 'setup.exe' esté en la misma carpeta que este script." -ForegroundColor Yellow
    Pause
    exit
}

if (-not (Test-Path -Path "configuration-Office365-x64.xml")) {
    Write-Host "[ERROR] No se encontró 'configuration-Office365-x64.xml' en la carpeta actual:" -ForegroundColor Red
    Write-Host (Get-Location) -ForegroundColor Yellow
    Write-Host "Asegúrate de que el archivo XML esté en la misma carpeta." -ForegroundColor Yellow
    Pause
    exit
}

Write-Host "[INFO] Archivos verificados correctamente." -ForegroundColor Green
Write-Host "[INFO] Iniciando la instalación de Microsoft Office 365..." -ForegroundColor Green
Write-Host "Por favor, espera a que finalice el proceso..."
Write-Host

# 4. Ejecutar la instalación
$process = Start-Process -FilePath "setup.exe" -ArgumentList "/configure configuration-Office365-x64.xml" -NoNewWindow -PassThru

# 5. Comprobar el código de salida
$process.WaitForExit()
if ($process.ExitCode -eq 0) {
    Write-Host
    Write-Host "===============================" -ForegroundColor Cyan
    Write-Host "[EXITO] La instalación ha finalizado correctamente." -ForegroundColor Green
    Write-Host "===============================" -ForegroundColor Cyan
} else {
    Write-Host
    Write-Host "===============================" -ForegroundColor Cyan
    Write-Host "[ERROR] La instalación finalizó con el código de error: $($process.ExitCode)" -ForegroundColor Red
    Write-Host "===============================" -ForegroundColor Cyan
}

Pause