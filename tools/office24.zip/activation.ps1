# Cambiar al directorio de Office 16
Set-Location -Path "$Env:ProgramFiles\Microsoft Office\Office16"

# Buscar y registrar la licencia
$licenseFiles = Get-ChildItem -Path "..\root\Licenses16" -Filter "ProPlus2021VL_KMS*.xrm-ms" -File
foreach ($file in $licenseFiles) {
    cscript ospp.vbs /inslic:"..\" + $file.Name
}

# Configurar el puerto KMS
cscript ospp.vbs /setprt:1688

# Desinstalar clave previa si existe
cscript ospp.vbs /unpkey:GCVGB | Out-Null

# Instalar la nueva clave de producto
$cscript ospp.vbs /inpkey:XJ2XN-FW8RK-P4HMP-DKDBV-GCVGB

# Configurar el servidor KMS
cscript ospp.vbs /sethst:e8.us.to

# Activar Office
cscript ospp.vbs /act

Pause